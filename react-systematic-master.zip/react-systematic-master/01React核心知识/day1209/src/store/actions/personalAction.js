/* personal版块要派发的行为对象管理 */
import * as TYPES from '../action-types';
const personalAction = {
    // ...
};
export default personalAction;