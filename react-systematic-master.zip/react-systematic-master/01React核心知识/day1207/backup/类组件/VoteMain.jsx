import React from "react";

class VoteMain extends React.Component {
    render() {
        return <div className="main">
            <p>支持人数：0人</p>
            <p>反对人数：0人</p>
        </div>;
    }
}

export default VoteMain;