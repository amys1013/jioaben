/* 在MAIN中，我们需要用到A/B模块中的方法 */
console.log(AModule.sum(10, 20, 30, 40));
console.log(BModule.average(10, 20, 30, 40));