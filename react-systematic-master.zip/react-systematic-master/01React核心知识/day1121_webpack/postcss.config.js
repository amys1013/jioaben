/* 关于POSTCSS-LOADER的配置项 */
module.exports = {
    plugins: [
        require("autoprefixer")
    ]
};