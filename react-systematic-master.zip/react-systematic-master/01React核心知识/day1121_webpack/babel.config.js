/* 关于BABEL-LOADER的配置项 */
module.exports = {
    presets: [
        "@babel/preset-env"
    ]
};