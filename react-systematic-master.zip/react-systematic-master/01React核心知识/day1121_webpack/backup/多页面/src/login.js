import sum from './A';
console.log('登录页呵呵呵呵');
console.log(sum(10, 20));