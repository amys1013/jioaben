import sum from "./A";
import average from "./B";

console.log(sum(10, 20, 30, 40));
console.log(average(10, 20, 30, 40));