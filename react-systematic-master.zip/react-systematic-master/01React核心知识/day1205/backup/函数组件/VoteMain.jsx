import React from "react";

const VoteMain = function VoteMain() {
    return <div className="main">
        <p>支持人数：0人</p>
        <p>反对人数：0人</p>
        <p>支持比率：--</p>
    </div>;
};
export default VoteMain;