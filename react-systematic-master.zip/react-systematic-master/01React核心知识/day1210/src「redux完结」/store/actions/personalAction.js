import * as TYPES from '../action-types';
const personalAction = {
    // ...
};
export default personalAction;