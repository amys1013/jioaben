import taskAction from "./taskAction";

const action = {
    task: taskAction
};
export default action;