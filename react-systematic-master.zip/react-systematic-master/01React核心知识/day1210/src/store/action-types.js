export const TASK_LIST = "TASK_LIST";
export const TASK_REMOVE = "TASK_REMOVE";
export const TASK_UPDATE = "TASK_UPDATE";