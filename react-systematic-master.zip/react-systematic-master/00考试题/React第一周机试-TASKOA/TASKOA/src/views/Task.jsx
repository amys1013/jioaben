import React from "react";
import './Task.less';

class Task extends React.Component {
    render() {
        return <div className="task-box">
            任务管理系统
        </div>;
    }
}

/* const Task = function Task() {
    return <div className="task-box">
        任务管理系统
    </div>;
}; */

export default Task;